'''
Property key is the blockstate name
    bool = boolean blockstate
    list = multiple options
    tuple = range of ints
    int = range of ints starting at 0
'''
properties = {
    "age": 25,
    "attached": bool,
    "attachment": ["ceiling", "double_wall", "floor", "single_wall"],
    "axis": ["x", "y", "z"],
    "berries": bool,
    "bites": 6,
    "bottom": bool,
    "candles": (1,4),
    "charges": 4,
    "delay": (1,4),
    "disarmed": bool,
    "distance": (1,7),
    "down": bool,
    "drag": bool,
    "east": bool,
    "eggs": (1,4),
    "enabled": bool,
    "extended": bool,
    "eye": bool,
    "face": ["ceiling", "floor", "wall"],
    "facing": ["down", "east", "north", "south", "up", "west"],
    "half": ["bottom", "top", "lower", "upper"],
    "has_bottle_0": bool,
    "has_bottle_1": bool,
    "has_bottle_2": bool,
    "hatch": 2,
    "hinge": ["left", "right"],
    "honey_level": 5,
    "in_wall": bool,
    "instrument": ["banjo", "basedrum", "bass", "bell", "bit", "chime", "cow_bell", "didgeridoo", "flute", "guitar", "harp", "hat", "iron_xylophone", "pling", "snare", "xylophone"],
    "inverted": bool,
    "layers": (1,8),
    "leaves": ["large", "none", "small"],
    "level": 15,
    "lit": bool,
    "locked": bool,
    "mode": ["compare", "subtract", "corner", "data", "load", "save"],
    "moisture": 7,
    "north": bool,
    "note": 24,
    "occupied": bool,
    "open": bool,
    "orientation": ["down_east", "down_north", "down_south", "down_west", "east_up", "north_up", "south_up", "up_east", "up_north", "up_south", "up_west", "west_up"],
    "part": ["foot", "head"],
    "persistent": bool,
    "pickles": (1,4),
    "power": 15,
    "powered": bool,
    "rotation": 15,
    "sculk_sensor_phase": ["active", "cooldown", "inactive"],
    "shape": ["inner_left", "inner_right", "outer_left", "outer_right", "straight", "ascending_east", "ascending_north", "ascending_south", "ascending_west", "east_west", "north_east", "north_south", "north_west", "south_east", "south_west"],
    "short": bool,
    "signal_fire": bool,
    "snowy": bool,
    "south": bool,
    "stage": 1,
    "thickness": ["base", "frustum", "middle", "tip", "tip_merge"],
    "tilt": ["full", "none", "partial", "unstable"],
    "unstable": bool,
    "up": bool,
    "vertical_direction": ["down","up"],
    "waterlogged": bool,
    "west": bool
}

import os
root = '/'.join(__file__.split("\\")[:-1])

def store_command(property, arg1, arg2):
	return f"execute if block ~ ~ ~ #blockstate:{property}[{property}={arg1}] run data modify storage blockstate:store {property} set value {arg2}"

for property in properties.keys():
	f = open(root + "/store/" + property + ".mcfunction", "w")
	value = properties.get(property)
	lines = []
	if value == bool:
		lines.append(store_command(property, "true", "1b"))
		lines.append(store_command(property, "false", "0b"))
	elif type(value) == list:
		for i in value:
			lines.append(store_command(property, i, f'"{i}"'))
	elif type(value) == int:
		value = (0, value)
	if type(value) == tuple:
		for i in range(value[0], value[1]+1):
			lines.append(store_command(property, i, i))
	f.write("\n".join(lines))
	f.close()
# Store all function
f = open(root + "/store/all.mcfunction", "w")
def call_function_command(property):
	return f"function blockstate:store/{property}"
f.write("function blockstate:clear\n" + "\n".join(map(call_function_command, properties.keys())))
f.close()
# Clear storage function
f = open(root + "/clear.mcfunction", "w")
def clear_command(property):
	return f"data remove storage blockstate:store {property}"
f.write("\n".join(map(clear_command, properties.keys())))
f.close()